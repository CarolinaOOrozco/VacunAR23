/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mapaenjava;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.util.HashSet;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.event.MouseInputAdapter;
import javax.swing.event.MouseInputListener;
import javax.swing.plaf.basic.BasicDesktopIconUI;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.OSMTileFactoryInfo;
import org.jxmapviewer.input.PanMouseInputListener;
import org.jxmapviewer.input.ZoomMouseWheelListenerCenter;
import org.jxmapviewer.input.ZoomMouseWheelListenerCursor;
import org.jxmapviewer.viewer.DefaultTileFactory;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.TileFactory;
import org.jxmapviewer.viewer.TileFactoryInfo;
import org.jxmapviewer.viewer.Waypoint;
import org.jxmapviewer.viewer.WaypointPainter;
import waypoint.WaypointRender;
import waypoint.miPuntero;

/**
 *
 * @author dev0
 */
public class FrameMapa extends javax.swing.JFrame {
private final Set<miPuntero> waypoints =new HashSet<>();

        
    public FrameMapa() {
        initComponents();
        init();
    }



GeoPosition geo1 = new GeoPosition(-34.923173,-57.9386326);
GeoPosition geo2 = new GeoPosition(-34.9244397,-57.9234835);
GeoPosition geo3 = new GeoPosition(-34.9235698,-57.9844044);
GeoPosition geo4 = new GeoPosition(-34.9067063,-57.9658055);
GeoPosition geo5 = new GeoPosition(-34.8977809,-57.9707956);
GeoPosition geo6 = new GeoPosition(-34.8994704,-57.9630709);

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jXMap = new org.jxmapviewer.JXMapViewer();
        boton = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        boton.setFont(new java.awt.Font("Zekton", 1, 10)); // NOI18N
        boton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/pin2.png"))); // NOI18N
        boton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Zekton", 1, 10)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Recursos/escoba.png"))); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jXMapLayout = new javax.swing.GroupLayout(jXMap);
        jXMap.setLayout(jXMapLayout);
        jXMapLayout.setHorizontalGroup(
            jXMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jXMapLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jXMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(boton, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 702, Short.MAX_VALUE))
        );
        jXMapLayout.setVerticalGroup(
            jXMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jXMapLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(boton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jButton1)
                .addContainerGap(354, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jXMap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jXMap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void botonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonActionPerformed
       waypoints.add(new miPuntero("centroVacunatorio1", new GeoPosition(geo1.getLatitude(),geo1.getLongitude())));
       waypoints.add(new miPuntero("centroVacunatorio2", new GeoPosition(geo2.getLatitude(),geo2.getLongitude())));
       waypoints.add(new miPuntero("centroVacunatorio3", new GeoPosition(geo3.getLatitude(),geo3.getLongitude())));
       waypoints.add(new miPuntero("centroVacunatorio4", new GeoPosition(geo4.getLatitude(),geo4.getLongitude())));
       waypoints.add(new miPuntero("centroVacunatorio5", new GeoPosition(geo5.getLatitude(),geo5.getLongitude())));
       waypoints.add(new miPuntero("centroVacunatorio6", new GeoPosition(geo6.getLatitude(),geo6.getLongitude())));
       inicializarWaypoint();
    }//GEN-LAST:event_botonActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      borrarPuntero();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrameMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrameMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrameMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrameMapa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameMapa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton boton;
    private javax.swing.JButton jButton1;
    private org.jxmapviewer.JXMapViewer jXMap;
    // End of variables declaration//GEN-END:variables

    private void init(){TileFactoryInfo tfi = new OSMTileFactoryInfo();      
    DefaultTileFactory tf = new DefaultTileFactory(tfi);
    GeoPosition gp = new GeoPosition(-34.919056, -57.9503485); 
    jXMap.setTileFactory(tf);   
    jXMap.setAddressLocation(gp);
    jXMap.setZoom(7);
    
       

   
   
   MouseInputListener mil = new PanMouseInputListener(jXMap);
   jXMap.addMouseListener(mil);                  
   jXMap.addMouseMotionListener(mil);   
   jXMap.addMouseWheelListener(new ZoomMouseWheelListenerCenter(jXMap));
  JXMapViewer.getDefaultLocale();
    }
  
    //Añado un punto de referencia(Waypoint - Marker)
    private void inicializarWaypoint(){
    WaypointPainter<miPuntero> wp = new WaypointRender();
    wp.setWaypoints(waypoints);
    jXMap.setOverlayPainter(wp);
        for (miPuntero waypoint : waypoints) {
            jXMap.add(waypoint.getBoton());
        }
    }
    private void borrarPuntero(){ 
        for (miPuntero waypoint : waypoints) {
            jXMap.remove(waypoint.getBoton());
        }
    waypoints.clear();
        inicializarWaypoint();
    }
    
//    
// public void paintWaypoint(Graphics2D g, JXMapViewer map, Waypoint waypoint){ 
// g.setColor(Color.RED);
// g.drawLine(-5,-5,+5,+5); 
// g.drawLine(-5,+5,+5,-5); 
// 
 }
         
    


